﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FPGA_Controller
{
    public partial class Form1 : Form
    {

        private SerialPort port;
        private Button[] leds;
        private bool[] ledsStatus;
        private bool[] tmpLedsStatus;
        private CheckBox[] switchs;
        private char INTERRUPT = '~';
        private String tmpContentLCD;
        private String tmpContentLED;
        
        //ID
        private const int ID_CONNECT = (int)'0';
        private const int ID_SWITCHS_STATUS = (int)'1';
        private const int ID_LEDS_STATUS = (int)'2';
        private const int ID_LED_UPDATE = (int)'3';
        private const int ID_LCD_CONTENT = (int)'4';
        private const int ID_LED_CONTENT = (int)'5';

        private byte[] createMessage(int id, byte[] data)
        {
            List<byte> mess = new List<byte>(data);
            mess.Add((byte)id);
            mess.Add((byte)INTERRUPT);
            return mess.ToArray();
        }

        public Form1()
        {
            InitializeComponent();
            leds = new Button[] { buttonLed_0, buttonLed_1, buttonLed_2, buttonLed_3, buttonLed_4, buttonLed_5, buttonLed_6, buttonLed_7 };
            switchs = new CheckBox[] { checkBoxSwitch_0, checkBoxSwitch_1, checkBoxSwitch_2, checkBoxSwitch_3, checkBoxSwitch_4, checkBoxSwitch_5, checkBoxSwitch_6, checkBoxSwitch_7 };
            ledsStatus = new bool[] { false, false, false , false , false , false , false , false };
            tmpLedsStatus = new bool[] { false, false, false, false, false, false, false, false };
        }

        private void sendLedChange(int x)
        {
            for (int i = 0; i < ledsStatus.Length; i++)
                tmpLedsStatus[i] = ledsStatus[i];
            tmpLedsStatus[x] = tmpLedsStatus[x] ? false : true;
            List<byte> data = new List<byte>();
            data.Add(boolArrayToByte(tmpLedsStatus));
            byte[] mess = createMessage(ID_LED_UPDATE,data.ToArray());
            port.Write(mess,0,mess.Length);
        }
        
        private static bool[] byteToBoolArray(byte x)
        {
            bool[] result = new bool[8];
            for(int i =0; i < 8; i++)
            {
                result[i] = Convert.ToBoolean((x >> i) & 1);
            }
            return result;
        }

        private static byte boolArrayToByte(bool[] x)
        {
            int result = 0;
            for (int i = 0; i < 8; i++)
            {
                result += (Convert.ToInt16(x[i]) << i);
            }
            return (byte)result;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void updateLedsButton()
        {
            for(int i=0; i < ledsStatus.Length; i++)
            {
                leds[i].BackColor = ledsStatus[i] ? System.Drawing.Color.LimeGreen : System.Drawing.Color.White;
            }
        }

        private void handleMessage()
        {
            //String message = port.ReadTo(INTERRUPT.ToString());
            byte[] message = new byte[3];
            port.Read(message, 0, 3);
            int len = message.Length;
            int check = (int)message[1];
            switch (check)
            {
                case ID_CONNECT: //handshake
                    if (message[0] == '1')
                    {
                        labelStatus.Text = "CONNECTED";
                        labelStatus.ForeColor = System.Drawing.Color.Green;
                        buttonConnect.Enabled = false;
                        textPort.Enabled = false;
                        //enable buttons and text
                        foreach (Button x in leds)
                            x.Enabled = true;
                        buttonSendLCD.Enabled = true;
                        buttonSendLED.Enabled = true;
                        contentLCD.Enabled = true;
                        contentLED.Enabled = true;

                        List<byte> data = new List<byte>();
                        data.Add(0);
                        byte[] mess = createMessage(ID_LEDS_STATUS, data.ToArray());
                        port.Write(mess, 0, mess.Length);

                        handleMessage();
                        checkTimer.Start();
                    }
                    else
                    {
                        labelStatus.Text = "ERROR";
                    }
                    break;
                case ID_SWITCHS_STATUS: //get status of switchs
                    bool[] switchsStatus = byteToBoolArray(message[0]);
                    for(int i=0; i < switchsStatus.Length; i++)
                        switchs[i].Checked = switchsStatus[i] ? true : false;
                    break;
                case ID_LEDS_STATUS: //get status of leds
                    ledsStatus = byteToBoolArray(message[0]);
                    updateLedsButton();
                    break;
                case ID_LED_UPDATE:
                    if (message[0] == '1')
                    {
                        for (int i = 0; i < ledsStatus.Length; i++)
                            ledsStatus[i] = tmpLedsStatus[i];
                    }
                    updateLedsButton();
                    break;
                case ID_LCD_CONTENT:
                    if (message[0] == '1')
                        labelLCD.Text = tmpContentLCD;
                    else
                        labelLCD.Text = "ERROR";
                    break;
                case ID_LED_CONTENT:
                    if (message[0] == '1')
                        labelLED.Text = tmpContentLED;
                    else
                        labelLED.Text = "ERROR";
                    break;
            }
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            try
            {
                port = new SerialPort(textPort.Text, 115200, Parity.None, 8, StopBits.One);
                port.Open();
                port.ReadTimeout = 200;
                port.WriteTimeout = 200;

                List<byte> data = new List<byte>();
                data.Add((byte)'0');
                byte[] mess = createMessage(ID_CONNECT, data.ToArray());
                port.Write(mess, 0, mess.Length);
                handleMessage();
                
            } catch (Exception ex)
            {
                labelStatus.Text = "ERROR";
            }
        }

        private void checkTimer_tick(object sender, EventArgs e)
        {
            List<byte> data = new List<byte>();
            data.Add((byte)'0');
            byte[] mess = createMessage(ID_SWITCHS_STATUS, data.ToArray());// request status of switchs
            port.Write(mess, 0, mess.Length);
            handleMessage();
        }

        private void buttonSendLCD_Click(object sender, EventArgs e)
        {
            byte[] mess = createMessage(ID_LCD_CONTENT, Encoding.ASCII.GetBytes(contentLCD.Text + "             "));
            port.Write(mess, 0, mess.Length);
            tmpContentLCD = contentLCD.Text;
            handleMessage();
        }

        private void buttonSendLED_Click(object sender, EventArgs e)
        {
            byte[] mess = createMessage(ID_LED_CONTENT, Encoding.ASCII.GetBytes(contentLED.Value.ToString()));
            port.Write(mess, 0, mess.Length);
            tmpContentLED = contentLED.Value.ToString();
            handleMessage();
        }

        private void buttonLed_0_Click(object sender, EventArgs e)
        {
            sendLedChange(0);
            handleMessage();
        }

        private void buttonLed_1_Click(object sender, EventArgs e)
        {
            sendLedChange(1);
            handleMessage();
        }

        private void buttonLed_2_Click(object sender, EventArgs e)
        {
            sendLedChange(2);
            handleMessage();
        }

        private void buttonLed_3_Click(object sender, EventArgs e)
        {
            sendLedChange(3);
            handleMessage();
        }

        private void buttonLed_4_Click(object sender, EventArgs e)
        {
            sendLedChange(4);
            handleMessage();
        }

        private void buttonLed_5_Click(object sender, EventArgs e)
        {
            sendLedChange(5);
            handleMessage();
        }

        private void buttonLed_6_Click(object sender, EventArgs e)
        {
            sendLedChange(6);
            handleMessage();
        }

        private void buttonLed_7_Click(object sender, EventArgs e)
        {
            sendLedChange(7);
            handleMessage();
        }

        private void checkBoxSwitch_7_CheckedChanged(object sender, EventArgs e)
        {
        }
    }
}
