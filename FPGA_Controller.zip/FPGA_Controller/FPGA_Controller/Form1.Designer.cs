﻿namespace FPGA_Controller
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonLed_0 = new System.Windows.Forms.Button();
            this.buttonLed_1 = new System.Windows.Forms.Button();
            this.buttonLed_2 = new System.Windows.Forms.Button();
            this.buttonLed_5 = new System.Windows.Forms.Button();
            this.buttonLed_4 = new System.Windows.Forms.Button();
            this.buttonLed_3 = new System.Windows.Forms.Button();
            this.buttonLed_7 = new System.Windows.Forms.Button();
            this.buttonLed_6 = new System.Windows.Forms.Button();
            this.checkBoxSwitch_0 = new System.Windows.Forms.CheckBox();
            this.checkBoxSwitch_3 = new System.Windows.Forms.CheckBox();
            this.checkBoxSwitch_2 = new System.Windows.Forms.CheckBox();
            this.checkBoxSwitch_1 = new System.Windows.Forms.CheckBox();
            this.checkBoxSwitch_5 = new System.Windows.Forms.CheckBox();
            this.checkBoxSwitch_6 = new System.Windows.Forms.CheckBox();
            this.checkBoxSwitch_7 = new System.Windows.Forms.CheckBox();
            this.checkBoxSwitch_4 = new System.Windows.Forms.CheckBox();
            this.contentLCD = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonSendLCD = new System.Windows.Forms.Button();
            this.contentLED = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonSendLED = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelLCD = new System.Windows.Forms.Label();
            this.labelLED = new System.Windows.Forms.Label();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.textPort = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.labelStatus = new System.Windows.Forms.Label();
            this.checkTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.contentLED)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonLed_0
            // 
            this.buttonLed_0.BackColor = System.Drawing.Color.White;
            this.buttonLed_0.Enabled = false;
            this.buttonLed_0.Location = new System.Drawing.Point(1075, 152);
            this.buttonLed_0.Name = "buttonLed_0";
            this.buttonLed_0.Size = new System.Drawing.Size(123, 56);
            this.buttonLed_0.TabIndex = 0;
            this.buttonLed_0.Text = "LED 0";
            this.buttonLed_0.UseVisualStyleBackColor = false;
            this.buttonLed_0.Click += new System.EventHandler(this.buttonLed_0_Click);
            // 
            // buttonLed_1
            // 
            this.buttonLed_1.BackColor = System.Drawing.Color.White;
            this.buttonLed_1.Enabled = false;
            this.buttonLed_1.Location = new System.Drawing.Point(1075, 214);
            this.buttonLed_1.Name = "buttonLed_1";
            this.buttonLed_1.Size = new System.Drawing.Size(123, 56);
            this.buttonLed_1.TabIndex = 1;
            this.buttonLed_1.Text = "LED 1";
            this.buttonLed_1.UseVisualStyleBackColor = false;
            this.buttonLed_1.Click += new System.EventHandler(this.buttonLed_1_Click);
            // 
            // buttonLed_2
            // 
            this.buttonLed_2.BackColor = System.Drawing.Color.White;
            this.buttonLed_2.Enabled = false;
            this.buttonLed_2.Location = new System.Drawing.Point(1075, 276);
            this.buttonLed_2.Name = "buttonLed_2";
            this.buttonLed_2.Size = new System.Drawing.Size(123, 56);
            this.buttonLed_2.TabIndex = 2;
            this.buttonLed_2.Text = "LED 2";
            this.buttonLed_2.UseVisualStyleBackColor = false;
            this.buttonLed_2.Click += new System.EventHandler(this.buttonLed_2_Click);
            // 
            // buttonLed_5
            // 
            this.buttonLed_5.BackColor = System.Drawing.Color.White;
            this.buttonLed_5.Enabled = false;
            this.buttonLed_5.Location = new System.Drawing.Point(1075, 462);
            this.buttonLed_5.Name = "buttonLed_5";
            this.buttonLed_5.Size = new System.Drawing.Size(123, 56);
            this.buttonLed_5.TabIndex = 5;
            this.buttonLed_5.Text = "LED 5";
            this.buttonLed_5.UseVisualStyleBackColor = false;
            this.buttonLed_5.Click += new System.EventHandler(this.buttonLed_5_Click);
            // 
            // buttonLed_4
            // 
            this.buttonLed_4.BackColor = System.Drawing.Color.White;
            this.buttonLed_4.Enabled = false;
            this.buttonLed_4.Location = new System.Drawing.Point(1075, 400);
            this.buttonLed_4.Name = "buttonLed_4";
            this.buttonLed_4.Size = new System.Drawing.Size(123, 56);
            this.buttonLed_4.TabIndex = 4;
            this.buttonLed_4.Text = "LED 4";
            this.buttonLed_4.UseVisualStyleBackColor = false;
            this.buttonLed_4.Click += new System.EventHandler(this.buttonLed_4_Click);
            // 
            // buttonLed_3
            // 
            this.buttonLed_3.BackColor = System.Drawing.Color.White;
            this.buttonLed_3.Enabled = false;
            this.buttonLed_3.Location = new System.Drawing.Point(1075, 338);
            this.buttonLed_3.Name = "buttonLed_3";
            this.buttonLed_3.Size = new System.Drawing.Size(123, 56);
            this.buttonLed_3.TabIndex = 3;
            this.buttonLed_3.Text = "LED 3";
            this.buttonLed_3.UseVisualStyleBackColor = false;
            this.buttonLed_3.Click += new System.EventHandler(this.buttonLed_3_Click);
            // 
            // buttonLed_7
            // 
            this.buttonLed_7.BackColor = System.Drawing.Color.White;
            this.buttonLed_7.Enabled = false;
            this.buttonLed_7.Location = new System.Drawing.Point(1075, 586);
            this.buttonLed_7.Name = "buttonLed_7";
            this.buttonLed_7.Size = new System.Drawing.Size(123, 56);
            this.buttonLed_7.TabIndex = 7;
            this.buttonLed_7.Text = "LED 7";
            this.buttonLed_7.UseVisualStyleBackColor = false;
            this.buttonLed_7.Click += new System.EventHandler(this.buttonLed_7_Click);
            // 
            // buttonLed_6
            // 
            this.buttonLed_6.BackColor = System.Drawing.Color.White;
            this.buttonLed_6.Enabled = false;
            this.buttonLed_6.Location = new System.Drawing.Point(1075, 524);
            this.buttonLed_6.Name = "buttonLed_6";
            this.buttonLed_6.Size = new System.Drawing.Size(123, 56);
            this.buttonLed_6.TabIndex = 6;
            this.buttonLed_6.Text = "LED 6";
            this.buttonLed_6.UseVisualStyleBackColor = false;
            this.buttonLed_6.Click += new System.EventHandler(this.buttonLed_6_Click);
            // 
            // checkBoxSwitch_0
            // 
            this.checkBoxSwitch_0.AutoSize = true;
            this.checkBoxSwitch_0.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxSwitch_0.Enabled = false;
            this.checkBoxSwitch_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSwitch_0.Location = new System.Drawing.Point(54, 601);
            this.checkBoxSwitch_0.Name = "checkBoxSwitch_0";
            this.checkBoxSwitch_0.Size = new System.Drawing.Size(77, 41);
            this.checkBoxSwitch_0.TabIndex = 8;
            this.checkBoxSwitch_0.Text = "Switch 0";
            this.checkBoxSwitch_0.UseVisualStyleBackColor = true;
            // 
            // checkBoxSwitch_3
            // 
            this.checkBoxSwitch_3.AutoSize = true;
            this.checkBoxSwitch_3.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxSwitch_3.Enabled = false;
            this.checkBoxSwitch_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSwitch_3.Location = new System.Drawing.Point(384, 601);
            this.checkBoxSwitch_3.Name = "checkBoxSwitch_3";
            this.checkBoxSwitch_3.Size = new System.Drawing.Size(77, 41);
            this.checkBoxSwitch_3.TabIndex = 9;
            this.checkBoxSwitch_3.Text = "Switch 3";
            this.checkBoxSwitch_3.UseVisualStyleBackColor = true;
            // 
            // checkBoxSwitch_2
            // 
            this.checkBoxSwitch_2.AutoSize = true;
            this.checkBoxSwitch_2.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxSwitch_2.Enabled = false;
            this.checkBoxSwitch_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSwitch_2.Location = new System.Drawing.Point(275, 601);
            this.checkBoxSwitch_2.Name = "checkBoxSwitch_2";
            this.checkBoxSwitch_2.Size = new System.Drawing.Size(77, 41);
            this.checkBoxSwitch_2.TabIndex = 10;
            this.checkBoxSwitch_2.Text = "Switch 2";
            this.checkBoxSwitch_2.UseVisualStyleBackColor = true;
            // 
            // checkBoxSwitch_1
            // 
            this.checkBoxSwitch_1.AutoSize = true;
            this.checkBoxSwitch_1.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxSwitch_1.Enabled = false;
            this.checkBoxSwitch_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSwitch_1.Location = new System.Drawing.Point(167, 601);
            this.checkBoxSwitch_1.Name = "checkBoxSwitch_1";
            this.checkBoxSwitch_1.Size = new System.Drawing.Size(77, 41);
            this.checkBoxSwitch_1.TabIndex = 11;
            this.checkBoxSwitch_1.Text = "Switch 1";
            this.checkBoxSwitch_1.UseVisualStyleBackColor = true;
            // 
            // checkBoxSwitch_5
            // 
            this.checkBoxSwitch_5.AutoSize = true;
            this.checkBoxSwitch_5.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxSwitch_5.Enabled = false;
            this.checkBoxSwitch_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSwitch_5.Location = new System.Drawing.Point(614, 601);
            this.checkBoxSwitch_5.Name = "checkBoxSwitch_5";
            this.checkBoxSwitch_5.Size = new System.Drawing.Size(77, 41);
            this.checkBoxSwitch_5.TabIndex = 15;
            this.checkBoxSwitch_5.Text = "Switch 5";
            this.checkBoxSwitch_5.UseVisualStyleBackColor = true;
            // 
            // checkBoxSwitch_6
            // 
            this.checkBoxSwitch_6.AutoSize = true;
            this.checkBoxSwitch_6.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxSwitch_6.Enabled = false;
            this.checkBoxSwitch_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSwitch_6.Location = new System.Drawing.Point(722, 601);
            this.checkBoxSwitch_6.Name = "checkBoxSwitch_6";
            this.checkBoxSwitch_6.Size = new System.Drawing.Size(77, 41);
            this.checkBoxSwitch_6.TabIndex = 14;
            this.checkBoxSwitch_6.Text = "Switch 6";
            this.checkBoxSwitch_6.UseVisualStyleBackColor = true;
            // 
            // checkBoxSwitch_7
            // 
            this.checkBoxSwitch_7.AutoSize = true;
            this.checkBoxSwitch_7.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxSwitch_7.Enabled = false;
            this.checkBoxSwitch_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSwitch_7.Location = new System.Drawing.Point(831, 601);
            this.checkBoxSwitch_7.Name = "checkBoxSwitch_7";
            this.checkBoxSwitch_7.Size = new System.Drawing.Size(77, 41);
            this.checkBoxSwitch_7.TabIndex = 13;
            this.checkBoxSwitch_7.Text = "Switch 7";
            this.checkBoxSwitch_7.UseVisualStyleBackColor = true;
            this.checkBoxSwitch_7.CheckedChanged += new System.EventHandler(this.checkBoxSwitch_7_CheckedChanged);
            // 
            // checkBoxSwitch_4
            // 
            this.checkBoxSwitch_4.AutoSize = true;
            this.checkBoxSwitch_4.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxSwitch_4.Enabled = false;
            this.checkBoxSwitch_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxSwitch_4.Location = new System.Drawing.Point(501, 601);
            this.checkBoxSwitch_4.Name = "checkBoxSwitch_4";
            this.checkBoxSwitch_4.Size = new System.Drawing.Size(77, 41);
            this.checkBoxSwitch_4.TabIndex = 12;
            this.checkBoxSwitch_4.Text = "Switch 4";
            this.checkBoxSwitch_4.UseVisualStyleBackColor = true;
            // 
            // contentLCD
            // 
            this.contentLCD.Enabled = false;
            this.contentLCD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contentLCD.Location = new System.Drawing.Point(295, 166);
            this.contentLCD.Name = "contentLCD";
            this.contentLCD.Size = new System.Drawing.Size(458, 27);
            this.contentLCD.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(140, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "LCD CONTENT:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonSendLCD
            // 
            this.buttonSendLCD.Enabled = false;
            this.buttonSendLCD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSendLCD.Location = new System.Drawing.Point(820, 166);
            this.buttonSendLCD.Name = "buttonSendLCD";
            this.buttonSendLCD.Size = new System.Drawing.Size(98, 27);
            this.buttonSendLCD.TabIndex = 18;
            this.buttonSendLCD.Text = "SEND";
            this.buttonSendLCD.UseVisualStyleBackColor = true;
            this.buttonSendLCD.Click += new System.EventHandler(this.buttonSendLCD_Click);
            // 
            // contentLED
            // 
            this.contentLED.Enabled = false;
            this.contentLED.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contentLED.Location = new System.Drawing.Point(295, 241);
            this.contentLED.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.contentLED.Name = "contentLED";
            this.contentLED.Size = new System.Drawing.Size(146, 27);
            this.contentLED.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(140, 243);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "LED CONTENT:";
            // 
            // buttonSendLED
            // 
            this.buttonSendLED.Enabled = false;
            this.buttonSendLED.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSendLED.Location = new System.Drawing.Point(820, 243);
            this.buttonSendLED.Name = "buttonSendLED";
            this.buttonSendLED.Size = new System.Drawing.Size(98, 27);
            this.buttonSendLED.TabIndex = 21;
            this.buttonSendLED.Text = "SEND";
            this.buttonSendLED.UseVisualStyleBackColor = true;
            this.buttonSendLED.Click += new System.EventHandler(this.buttonSendLED_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(483, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(289, 32);
            this.label3.TabIndex = 22;
            this.label3.Text = "FPGA CONTROLER";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(262, 374);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 20);
            this.label4.TabIndex = 23;
            this.label4.Text = "Current LCD content";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(693, 374);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(164, 20);
            this.label5.TabIndex = 24;
            this.label5.Text = "Current LED content";
            // 
            // labelLCD
            // 
            this.labelLCD.AutoSize = true;
            this.labelLCD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLCD.Location = new System.Drawing.Point(230, 462);
            this.labelLCD.Name = "labelLCD";
            this.labelLCD.Size = new System.Drawing.Size(0, 20);
            this.labelLCD.TabIndex = 25;
            // 
            // labelLED
            // 
            this.labelLED.AutoSize = true;
            this.labelLED.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLED.Location = new System.Drawing.Point(753, 462);
            this.labelLED.Name = "labelLED";
            this.labelLED.Size = new System.Drawing.Size(0, 20);
            this.labelLED.TabIndex = 26;
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(209, 57);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(97, 23);
            this.buttonConnect.TabIndex = 27;
            this.buttonConnect.Text = "CONNECT";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // textPort
            // 
            this.textPort.Location = new System.Drawing.Point(92, 58);
            this.textPort.Name = "textPort";
            this.textPort.Size = new System.Drawing.Size(100, 22);
            this.textPort.TabIndex = 28;
            this.textPort.Text = "COM4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 17);
            this.label6.TabIndex = 29;
            this.label6.Text = "PORT";
            // 
            // labelStatus
            // 
            this.labelStatus.AutoSize = true;
            this.labelStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStatus.ForeColor = System.Drawing.Color.Red;
            this.labelStatus.Location = new System.Drawing.Point(1032, 60);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(107, 17);
            this.labelStatus.TabIndex = 30;
            this.labelStatus.Text = "DISCONNECT";
            // 
            // checkTimer
            // 
            this.checkTimer.Interval = 200;
            this.checkTimer.Tick += new System.EventHandler(this.checkTimer_tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1242, 676);
            this.Controls.Add(this.labelStatus);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textPort);
            this.Controls.Add(this.buttonConnect);
            this.Controls.Add(this.labelLED);
            this.Controls.Add(this.labelLCD);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonSendLED);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.contentLED);
            this.Controls.Add(this.buttonSendLCD);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.contentLCD);
            this.Controls.Add(this.checkBoxSwitch_5);
            this.Controls.Add(this.checkBoxSwitch_6);
            this.Controls.Add(this.checkBoxSwitch_7);
            this.Controls.Add(this.checkBoxSwitch_4);
            this.Controls.Add(this.checkBoxSwitch_1);
            this.Controls.Add(this.checkBoxSwitch_2);
            this.Controls.Add(this.checkBoxSwitch_3);
            this.Controls.Add(this.checkBoxSwitch_0);
            this.Controls.Add(this.buttonLed_7);
            this.Controls.Add(this.buttonLed_6);
            this.Controls.Add(this.buttonLed_5);
            this.Controls.Add(this.buttonLed_4);
            this.Controls.Add(this.buttonLed_3);
            this.Controls.Add(this.buttonLed_2);
            this.Controls.Add(this.buttonLed_1);
            this.Controls.Add(this.buttonLed_0);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.contentLED)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonLed_0;
        private System.Windows.Forms.Button buttonLed_1;
        private System.Windows.Forms.Button buttonLed_2;
        private System.Windows.Forms.Button buttonLed_5;
        private System.Windows.Forms.Button buttonLed_4;
        private System.Windows.Forms.Button buttonLed_3;
        private System.Windows.Forms.Button buttonLed_7;
        private System.Windows.Forms.Button buttonLed_6;
        private System.Windows.Forms.CheckBox checkBoxSwitch_0;
        private System.Windows.Forms.CheckBox checkBoxSwitch_3;
        private System.Windows.Forms.CheckBox checkBoxSwitch_2;
        private System.Windows.Forms.CheckBox checkBoxSwitch_1;
        private System.Windows.Forms.CheckBox checkBoxSwitch_5;
        private System.Windows.Forms.CheckBox checkBoxSwitch_6;
        private System.Windows.Forms.CheckBox checkBoxSwitch_7;
        private System.Windows.Forms.CheckBox checkBoxSwitch_4;
        private System.Windows.Forms.TextBox contentLCD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonSendLCD;
        private System.Windows.Forms.NumericUpDown contentLED;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonSendLED;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelLCD;
        private System.Windows.Forms.Label labelLED;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.TextBox textPort;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelStatus;
        private System.Windows.Forms.Timer checkTimer;
    }
}

